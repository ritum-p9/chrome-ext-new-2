function SendLoginDataToExtension(login_id , login_password, login_method, cred) {
	chrome.runtime.sendMessage({command: "Set Login Data", data: { 
	    login_id:login_id,
	    login_password:login_password,
	    login_method:login_method,
	    cred:cred
	}});
}
console.log("Injecttedddd!!");
let loginId = $("#login_id").text();
let params = new URLSearchParams(location.search);
let cred = params.get("cred")
let method = params.get("method")

if(cred && method && loginId){
	SendLoginDataToExtension(loginId, null, method, cred);
}