// (function(){
//         $.get(chrome.runtime.getURL('/template.html'), function(data) {
//             wait(3000);
//             $(data).appendTo('.jmSZUc:last');

//             //document.querySelector("body").append(data);
//             // Or if you're using jQuery 1.8+:
//             // $($.parseHTML(data)).appendTo('body');
//         });

// })();

var html = `
<div class="popup">
    <p>Please Turn on cc</p>
    <button class="btnOK">OK</button>
</div>
<div class="icon_label">
<i class="fa fa-boxes"></i>
</div>`;


$(function () {
    $(window).bind('load', function () {
        $.get(chrome.runtime.getURL('/template.html'), function (data) {
            //gb_nb
            //ASy21 Duq0Bf

            var checkGmailExist = setInterval(function () {
                if ($('.gb_nb').length) {
                    var name = $(".gb_nb").text();
                    // Save data to storage locally, in just this browser...

                    chrome.storage.local.set({ "Gmail": name }, function () {
                        //  Data's been saved boys and girls, go on home
                    });

                    clearInterval(checkGmailExist);
                }
            }, 100);
            //w29hZ
            var checkGmailExist1 = setInterval(function () {
                if ($('.ASy21.Duq0Bf').length) {
                    var name = $(".ASy21.Duq0Bf").text();
                    chrome.storage.local.set({ "Gmail": name }, function () {
                        //  Data's been saved boys and girls, go on home
                    });
                    localStorage.setItem("gEmail", name);
                    clearInterval(checkGmailExist1);
                }
            }, 100);

            var checkGmailExist2 = setInterval(function () {
                if ($('.w29hZ').length) {
                    var name = $(".w29hZ").text().replace("Joined as ","");
                    chrome.storage.local.set({ "Gmail": name }, function () {
                        //  Data's been saved boys and girls, go on home
                    });
                    localStorage.setItem("gEmail", name);
                    clearInterval(checkGmailExist2);
                }
            }, 100);

            //wait(3000);
            var checkExist = setInterval(function () {
                if ($('.SGP0hd.kunNie').length) {
                    //$(".VfPpkd-Bz112c-LgbsSe.yHy1rc.eT1oJ.JsuyRc.boDUxc").eq(1).click();


                    var checkNameExist = setInterval(function () {
                        if ($('.ZjFb7c').text() != "") {
                            var name = $(".ZjFb7c").html();
                            clearInterval(checkNameExist);
                        }
                    }, 100);

                    $(html).appendTo('.SGP0hd.kunNie');
                    $(data).appendTo('body');
                    $(".VfPpkd-Bz112c-LgbsSe.fzRBVc.tmJved.xHd4Cb.rmHNDe.Qr8aE").click(function () {
                        $(".popup").hide();
                    });
                    $("#frame1").attr("src", "chrome-extension://" + chrome.runtime.id + "/popup.html");



                    $(".icon_label").click(function () {
                        if ($("#call-us-cta").hasClass("hidden")) {
                            $("#call-us-cta").removeClass("hidden");
                            $(".xsj2Ff.Zf0RDc").css("left", "114px");
                            var width = $(".xsj2Ff.Zf0RDc").width();
                            var newWidth = parseInt(width) + 149;
                            $(".xsj2Ff.Zf0RDc").css("width", newWidth);
                            //document.getElementById("frame1").contentDocument.location.reload(true);
                       
                        } else {
                            //var iframe = document.getElementById('frame1');
                            //iframe.src = iframe.src;
                            $("#call-us-cta").addClass("hidden");
                            $(".xsj2Ff.Zf0RDc").css("left", "0px");
                            var width = $(".xsj2Ff.Zf0RDc").width();
                            var newWidth = parseInt(width) - 149;
                            $(".xsj2Ff.Zf0RDc").css("width", newWidth);
                            //document.getElementById("frame1").contentDocument.location.reload(true);

                        }
                    });
                    $(".btnOK").click(function () {
                        $(".popup").hide();
                    });


                    //iTTPOb VbkSUe
                    clearInterval(checkExist);
                }
            }, 100); // check every 100ms
            //zs7s8d jxFHg
            var len = 0;
            var checkCaption = setInterval(function () {
                if ($('.iTTPOb.VbkSUe').length) {
                    len = $('.iTTPOb .CNusmb').length;
                    var checkComplete = setInterval(function () {
                        if ($('.iTTPOb .CNusmb:last').text().indexOf(".") > -1 || $('.iTTPOb .CNusmb:last').text().indexOf("?") > -1 || $('.iTTPOb .CNusmb:last').text().indexOf("!") > -1) {
                            var sender = $('.iTTPOb .CNusmb:last').parent().parent().parent().parent().find(".zs7s8d.jxFHg").text();
                            chrome.runtime.sendMessage({ command: "sendCC", data: $('.iTTPOb .CNusmb:last').text() + "_" + sender });
                            console.log($('.iTTPOb .CNusmb:last').text());
                            clearInterval(checkComplete);
                        }
                    }, 10);
                    clearInterval(checkCaption);
                   
                }
            }, 10);

            var checknoVisible = setInterval(function () {
                var len1 = $('.iTTPOb .CNusmb').length;
                if (len1 == 0) {
                    len = $('.iTTPOb .CNusmb').length;
                    //console.log($('.iTTPOb.VbkSUe .CNusmb:last').text());
                }
                if (len1 != len) {
                    len = len1;
                    var checkComplete = setInterval(function () {
                        if ($('.iTTPOb .CNusmb:last').text().indexOf(".") > -1 || $('.iTTPOb .CNusmb:last').text().indexOf("?") > -1 || $('.iTTPOb .CNusmb:last').text().indexOf("!") > -1) {
                            var sender = $('.iTTPOb .CNusmb:last').parent().parent().parent().parent().find(".zs7s8d.jxFHg").text();
                            chrome.runtime.sendMessage({ command: "sendCC", data: $('.iTTPOb .CNusmb:last').text() + "_" + sender });
                            console.log($('.iTTPOb .CNusmb:last').text());
                            clearInterval(checkComplete);
                        }
                    }, 10);
                }
                //clearInterval(checknoVisible);
            }, 10);

            //$(data).appendTo('body');

            //document.querySelector("body").append(data);
            // Or if you're using jQuery 1.8+:
            // $($.parseHTML(data)).appendTo('body');
        });
    });
});


function wait(ms) {
    var start = new Date().getTime();
    var end = start;
    while (end < start + ms) {
        end = new Date().getTime();
    }
}