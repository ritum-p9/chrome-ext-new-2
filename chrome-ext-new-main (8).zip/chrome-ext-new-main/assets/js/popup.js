﻿// const hostUrl="http://localhost:8000?next_url=/?";
const hostUrl ="https://spokeperson.co";
// const hostUrl="https://dialoggbox.tk";
var loginID;
var meetingURL;
var dialogID;
let loadingDialog=false;
let ChatList=[];
let globalCred;

$(document).ready(function () {
    getLanguages();
    $('.btn_settings').click(function () {
        $(this).toggleClass("click");
        $('.sidebar').toggleClass("show");
    });

    $(".dropdown-toggle.btn").click(function () {
        $(".dropdown-menu").toggle("display");
    });
    $('.feat-btn').click(function () {
        $('nav ul .feat-show').toggleClass("show");
        $('nav ul .first').toggleClass("rotate");
    });
    $('.serv-btn').click(function () {
        $('nav ul .serv-show').toggleClass("show1");
        $('nav ul .second').toggleClass("rotate");
    });
    $('nav ul li').click(function () {
        $(this).addClass("active").siblings().removeClass("active");
    });



});

function getLanguages() {
    var settings = {
        "url": "https://spokeperson.co/languages",
        "method": "GET",
        "headers": {
            "Content-Type": "application/JSON"
        }
    };

    $.ajax(settings).done(function (response) {
        var p = response.translation;
        var html = "<option>Please Select</option>";
        var languageName = [];
        var languageCode = [];
        for (var key in p) {
            if (p.hasOwnProperty(key)) {
                languageName.push(p[key].name);
                languageCode.push(p[key].name + ":" + key);
                //html += `<option value="` + key + `">` + p[key].name + `</option>`;
            }
        }
        languageName.sort();
        languageCode.sort();
        for (var i = 0; i < languageCode.length; i++) {
            html += `<option value="` + languageCode[i].split(':')[1] + `">` + languageName[i] + `</option>`;
        }

        $("#change_lang").html(html);
        $("#change_lang").val("en");
        $("#change_lang").change(function () {
            var to = $(this).val();
            $('.chat-body span').each(function (i, obj) {
                console.log($(this).html());
                if ($(this).html().indexOf("fa-lock") > -1) {
                    translateChat($(this).text(), to, this,1);
                } else { 
                    translateChat($(this).text(), to, this);
                }
               // $(this).parent().append(`<p style="padding: 0px;margin-left: 24px;font-weight:400;margin: 0px;"><i>Cantonese (Traditional): 你好</i></p>`);
            });

        });
    });
}

function translateChat(text, to, elem, isPrivate=0) {

    if (to == "en") {
        if (text == "Private Message" || isPrivate == 1) {
            $(elem).parent().html(`<i class="fa-lock fa" style="
    margin-right: 10px;
"></i><span class="main_msg">` + text + `</span>`);
        } else {
            $(elem).parent().html(`<span class="main_msg">` + text + `</span>`);
        }
    } else {
        fetch("https://spokeperson.co/translate/", {
            "headers": {
                "accept": "*/*",
                "accept-language": "en-IN,en-GB;q=0.9,en-US;q=0.8,en;q=0.7,la;q=0.6,hi;q=0.5",
                "content-type": "text/plain;charset=UTF-8",
                "sec-ch-ua": "\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"91\", \"Chromium\";v=\"91\"",
                "sec-ch-ua-mobile": "?0",
                "sec-fetch-dest": "empty",
                "sec-fetch-mode": "cors",
                "sec-fetch-site": "same-origin"
            },
            "referrer": "https://spokeperson.co",
            "referrerPolicy": "strict-origin-when-cross-origin",
            "body": "{\"text\":\"" + text + "\",\"to\":\"" + to + "\"}",
            "method": "POST",
            "mode": "cors",
            "credentials": "include"
        }).then(r => r.text()).then(result => {
            if (text == "Private Message" || isPrivate == 1) {
                $(elem).parent().html(`<i class="fa-lock fa" style="
    margin-right: 10px;
"></i><span class="main_msg">` + text + `</span><p class="t_msg">` + JSON.parse(result).translate_text + `</p>`);
            }
            else {
                $(elem).parent().html(`<span class="main_msg">` + text + `</span><p class="t_msg">` + JSON.parse(result).translate_text + `</p>`);
            }


        });
    }
}

var senderList = [];
var showList = [];

function InitChatBox(msgs){
    console.log(msgs);
    ChatList = [];
    ChatList = [];
    $(".chat-box").html("");
  for(var i = msgs.length-1; i >=0; i --){
    let msg = msgs[i];
    ChatList.push(msg);
    let dateText = moment.unix(Number(msg.date_sent)).format("LT") +" " + getAbbrTimezone();
      let sender = msg.sender;
      if (senderList.indexOf(msg.sender) == -1) {
          senderList.push(msg.sender);
      }

      if (showList.length > 0) {
          if (showList.indexOf(msg.sender) > -1) {
              let headerText = sender + " <span class='datespan'>" + dateText + "</span>";

              if ((msg.isPrivate == "1" || msg.isPrivate == 1) && msg.sender != loginID) {
                  let bodyText = "Private Message";
                  AddChatElement(headerText, bodyText);
              }
              else if ((msg.isPrivate == "1" || msg.isPrivate == 1) && msg.sender == loginID) {
                  let bodyText = `<i class="fa-lock fa" style="
    margin-right: 10px;
"></i>` + msg.message;
                  AddChatElement(headerText, bodyText);
              }
              else {
                  AddChatElement(headerText, msg.message);
              }
          }
      } else {
          let headerText = sender + " <span class='datespan'>" + dateText + "</span>";

          if ((msg.isPrivate == "1" || msg.isPrivate == 1) && msg.sender != loginID) {
              let bodyText = "Private Message";
              AddChatElement(headerText, bodyText);
          }
          else if ((msg.isPrivate == "1" || msg.isPrivate == 1) && msg.sender == loginID) {
              let bodyText = `<i class="fa-lock fa" style="
    margin-right: 10px;
"></i>` + msg.message;
              AddChatElement(headerText, bodyText);
          }
          else {
              AddChatElement(headerText, msg.message);
          }
      }
    }

    //$(".dropdown-menu.dropdown-menu-personal-menu ul").html("");
    //var html = "";
    //for (var i = 0; i < senderList.length; i++) {
    //    html += `<li><i class="fa-check fa" style="margin-top: 5px;margin-right: 5px;"></i> <a class="dropdown-item selected" href="#">` + senderList[i] + `</a></li>`;
    //    console.log(senderList);
    //}
    //$(".dropdown-menu.dropdown-menu-personal-menu ul").html(html);

    //LoadUserList();
}

function initSenderList(msgs) {
    ChatList = [];
    for (var i = msgs.length - 1; i >= 0; i--) {
        let msg = msgs[i];
        let sender = msg.sender;
        if (senderList.indexOf(msg.sender) == -1) {
            senderList.push(msg.sender);
        }
    }

    $(".dropdown-menu.dropdown-menu-personal-menu ul").html("");
    senderList.sort();
    var html = `<li><a class="dropdown-item" href="#">Show All</a></li>`;
    for (var i = 0; i < senderList.length; i++) {
        html += `<li><a class="dropdown-item" href="#">` + senderList[i] + `</a></li>`;
        //html += `<li><a class="dropdown-item selected" href="#"><i class="fa-check fa" style="margin-top: 5px;margin-right: 5px;"></i> ` + senderList[i] + `</a></li>`;
        console.log(senderList);
    }

    $(".dropdown-menu.dropdown-menu-personal-menu ul").html(html);
    $(".dropdown-menu.dropdown-menu-personal-menu ul li a").click(function () {
        $(".dropdown-menu.dropdown-menu-personal-menu ul li a").removeClass("selected");
        $(this).toggleClass("selected");
        showList = [];
        $('.dropdown-menu.dropdown-menu-personal-menu ul li a.selected').each(function (i, obj) {
            if ($(this).text() == "Show All") {
                showList = [];
            } else {
                showList.push($(this).text());
            }
            // $(this).parent().append(`<p style="padding: 0px;margin-left: 24px;font-weight:400;margin: 0px;"><i>Cantonese (Traditional): 你好</i></p>`);
        });
        showLoggedInContent();
    });
}

function LoadUserList() {
    chrome.runtime.sendMessage({ command: "LoadChatHistory", data: { email: loginID, meeting_url: meetingURL } }, function (data) {
        if (data) {
            dialogID = data.dialogID;
            initSenderList(data.msgs);
            LoadingFinished(true);
        } else {
            LoadingFinished(false);
        }
    })
}


function LoadingFinished(success) {
  loadingDialog = false;
    if (success) {
        $("#loading").addClass("display-none");
        $(".main-content").removeClass("display-none");
    } else {

    }
}

function formatDate(date) {
    var d = new Date(date);
    var hh = d.getHours();
    var m = d.getMinutes();
    var s = d.getSeconds();
    var dd = "AM";
    var h = hh;
    if (h >= 12) {
        h = hh - 12;
        dd = "PM";
    }
    if (h == 0) {
        h = 12;
    }
    m = m < 10 ? "0" + m : m;

    s = s < 10 ? "0" + s : s;

    /* if you want 2 digit hours:
    h = h<10?"0"+h:h; */

    var pattern = new RegExp("0?" + hh + ":" + m + ":" + s);

    var replacement = h + ":" + m;
    /* if you want to add seconds
    replacement += ":"+s;  */
    replacement += " " + dd;

    return date.replace(pattern, replacement);
}

function tConvert(time) {
    // Check correct time format and split into components
    time = time.toString().match(/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time];

    if (time.length > 1) { // If time format correct
        time = time.slice(1);  // Remove full string match value
        time[5] = +time[0] < 12 ? ' AM' : ' PM'; // Set AM/PM
        time[0] = +time[0] % 12 || 12; // Adjust hours
    }
    return time.join(''); // return adjusted time or original string
}


Date.prototype.toShortFormat = function () {

    let monthNames = ["Jan", "Feb", "Mar", "Apr",
        "May", "Jun", "Jul", "Aug",
        "Sep", "Oct", "Nov", "Dec"];

    let day = this.getDate();
    let time = formatDate(this.getHours() + ":" + this.getMinutes()+ ":00");
    let stime =  tConvert(time);
    let monthIndex = this.getMonth();
    let monthName = monthNames[monthIndex];

    let year = this.getFullYear();

    return `${monthName} ${day} ${year} at ${stime}`;
}
function SaveDialogXML(data){
  return new Promise(function (resolve, reject) {
      let xmlStr = generatexml(data);
      console.log(xmlStr);
    const formData = new FormData();
    formData.append('xmlData',xmlStr);
    formData.append('login_id',loginID);
    formData.append('dialog_id',data.dialog_id);
    $.post({
      url: `${hostUrl}/save-input-xml-chrome/?cred=`+globalCred, 
      data: formData,
      processData: false,
      contentType: false,
      cache: false,
        success: function (data) {
            console.log(data);
        resolve(data);        
      }

    })
  });
}


function SaveXmlClick() {
    if (loadingDialog) return;
    //window.open(hostUrl + "/loading_review_crome/", "_blank");
    SaveDialogXML({
        meeting_url: meetingURL,
        dialog_id: dialogID,
        chat_list: ChatList
    }).then((data) => {
        if (data.status == "ok") {
            window.open(hostUrl + "/review/?link_id=" + data.xmlfileidname + "&isuploaded=true" + "&user_email=" + loginID + "&cred=" + globalCred, "_blank")

        }
    });
}

function DownloadDialogXML(data) {
    return new Promise(function (resolve, reject) {
        for (var i = 0; i < data.chat_list.length; i++) {
            var isPrivate = data.chat_list[i].isPrivate;
            if (isPrivate == 1 && data.chat_list[i].sender != loginID) {
                data.chat_list[i].message = "Private Message";
            }
        }
        let xmlStr = generatexml(data);
        console.log(xmlStr);
        download("chat.xml", xmlStr);
    });
}

function download(filename, text) {
    var element = document.createElement('a');
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
    element.setAttribute('download', filename);

    element.style.display = 'none';
    document.body.appendChild(element);

    element.click();

    document.body.removeChild(element);
}

// Start file download.

function DownloadXmlClick() {
    DownloadDialogXML({
        meeting_url: meetingURL,
        dialog_id: dialogID,
        chat_list: ChatList
    }).then((data) => {
        if (data.status == "ok") {
            //window.open(hostUrl + "/review_all/?link_id=" + data.xmlfileidname + "&isuploaded=true" + "&user_email=" + loginID + "&cred=" + globalCred, "_blank")

        }
    });
}

async function showLoggedInContent(){
  $("#login-content").addClass("display-none");
    $("#loggedin-content").removeClass("display-none");
    //$(".nameInitial").text(loginID.charAt(0).toUpperCase());
    if (loginID.length > 14) {
        $("#login-id").text(loginID.substring(0, 14) + "..");
        $("#login-id").attr("title", loginID);
    } else {
        $("#login-id").text(loginID);
    }
    $(".joined-at").text("Joined at " + new Date().toShortFormat());
  if(!meetingURL) {
    var tab = await getActiveTabInfo();
    console.log("Active Tab", tab);
    if (tab) meetingURL = tab.url
  }
  if(meetingURL) {
    chrome.runtime.sendMessage({command:"Get Last Dialog Data"},function(lastData){
      if(meetingURL){
        if(lastData.meeting_url != meetingURL){
          if(lastData.meeting_url) SaveDialogXML(lastData);
        }
      }
      
      loadingDialog = true;
      $("#meeting-link").text(meetingURL);
      chrome.runtime.sendMessage({command:"LoadChatHistory", data:{email:loginID, meeting_url:meetingURL}}, function(data){
        if(data){
          dialogID = data.dialogID;          
          InitChatBox(data.msgs);
          LoadingFinished(true);
        }else{
          LoadingFinished(false);
        }
      })
      
      // SetupQB(loginID, meetingURL, dialogID).then((dialog)=>{
      //   $("#dialog-id").text(QBCurrentDialogInfo._id);
      //   dialogID = QBCurrentDialogInfo._id;
      //   QuickbloxConnected = true;
      //   SubscribeMessageEvent();
      //   loadChathistory(QBCurrentDialogInfo).then((msgs)=>{
      //     InitChatBox(msgs);
      //     LoadingFinished(true);
      //   }).catch(err=>{
      //     console.log(err);
      //     LoadingFinished(false);
      //   })
      // }).catch(e=>{
      //   alert("Setup Quick Blox failed")
      //   LoadingFinished(false);
      // });  
    });
    
  }else{
    LoadingFinished(false);
  }
  
  
}
function showLoginContent(){
  $("#login-content").removeClass("display-none");
  $("#loggedin-content").addClass("display-none");

}
function isLoggedIn(loginStatus) {
    try {
        loginID = loginStatus.login_id;
        dialogID = loginStatus.dialog_id;
        meetingURL = loginStatus.meeting_url;
        globalCred = loginStatus.cred;
        return loginID;
    } catch {
        return false;
    }
 
}


function routing(loginStatus){
  if(isLoggedIn(loginStatus)) showLoggedInContent();
  else showLoginContent();
}

function sendText(){
    let text = $('#input-text').val();
    var IsPrivate = 0;
    if ($(".button.btn_private").hasClass("active")) {
        IsPrivate = 1;
    }
    if (text) {
        chrome.runtime.sendMessage({ command: "sendText", data: text + "_" + IsPrivate });    
        $('#input-text').val("");
  }  
}

//chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    
//    if (message.command == "onMessageReceived") {
//        let new_message = message.data.new_message
//        let dateText = moment.unix(Number(new_message.date_sent)).format("MM/DD/YYYY LT") + " " + getAbbrTimezone();
//        let sender = new_message.sender;
//        let headerText = sender + " " + dateText;
//        ChatList.push(new_message)
//        AddChatElement(headerText, new_message.message);
//        // scroll to bottom;
//        $(".chat-box").animate({ scrollTop: $('.chat-box')[0].scrollHeight }, 'slow');
//    }
//});

$(document).ready(function () {
    chrome.runtime.sendMessage({ command: "joined" }, routing);
    chrome.runtime.sendMessage({ command: "loginstatus" }, routing);
    $("#send-text-btn").on("click", sendText);
    $('#save_xml').on("click", SaveXmlClick);
    $("#download_xml").on("click", DownloadXmlClick);
    $("#search_chat").click(function () {
        $(".search_text").toggle("display");
        //$(".top_content").toggleClass("f_height");
    });

    $("button.button.btn_private").click(function () {
        $("button.button.btn_private").toggleClass("active");
    });

    $("#dropdownMenuButton").click(function () {
        LoadUserList();
    });

    $(".reload_page").click(function () {
        showLoggedInContent();
    });

    /* Anything that gets to the document
    will hide the dropdown */
    $(document).click(function () {
        $("#dropdown-menu").hide();
        $(".sidebar").removeClass("show");
        $(".search_text").hide();
    });

    /* Clicks within the dropdown won't make
       it past the dropdown itself */
    $("#dropdown-menu").click(function (e) {
        e.stopPropagation();
    });
    $(".dropdown").click(function (e) {
        e.stopPropagation();
    });

    /* Clicks within the dropdown won't make
       it past the dropdown itself */
    $(".sidebar").click(function (e) {
        e.stopPropagation();
    });
    $(".btn_settings").click(function (e) {
        e.stopPropagation();
    });

    $(".search_text").click(function (e) {
        e.stopPropagation();
    });
    $("#search_chat").click(function (e) {
        e.stopPropagation();
    });
});

