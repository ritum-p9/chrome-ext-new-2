let activeTabId, lastUrl, lastTitle;
const MeetingHostList = [
    "zoom.us",
    "meet.google.com",
    "webex.com",
    "teams.microsoft.com"
]
function getTabInfo(tabId) {
    chrome.tabs.get(tabId, function (tab) {
    //if(lastUrl != tab.url || lastTitle != tab.title){       
      
    //  console.log(lastUrl = tab.url, lastTitle = tab.title);
    //}
  });
}
function getActiveTabInfo() {
    return new Promise(function(resolve, reject){
        chrome.tabs.query({active:true}, function(tabs){
            if(tabs.length > 0){
                let domain = domain_from_url(tabs[0].url);
                if(MeetingHostList.includes(domain))
                    resolve(tabs[0]);
                else
                    resolve(undefined)
            }
            resolve(undefined);
        })
        
    });
    
}
chrome.tabs.onActivated.addListener(function(activeInfo) {
  getTabInfo(activeTabId = activeInfo.tabId);
});

chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
  if(activeTabId == tabId) {
    getTabInfo(tabId);
  }
});

