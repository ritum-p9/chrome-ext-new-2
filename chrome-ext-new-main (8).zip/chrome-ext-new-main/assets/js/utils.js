function domain_from_url(url) {
    var result
    var match
    if (match = url.match(/((http(s?):\/\/)(([\w\d-]+\.)*[\w-]+[\.\:]\w+)([\/\?\=\&\#]?[\w-]+)*\/?)/im)) {
        result = match[4]        
    }
    return result
}

function getAbbrTimezone(){
  const timezone = moment.tz.guess();
  const abbrTimezone = moment.tz(timezone).format('z');
  return abbrTimezone;
}

function AddChatElement(headerText, text) {
    $("#chat-template .chat-header").html(headerText);
    if (text == "Private Message") {
        $("#chat-template .chat-body span").html(`<i class="fa-lock fa" style="
    margin-right: 10px;
"></i>` + text);
    } else {
        $("#chat-template .chat-body span").html(text);
    }
  $("#chat-template .chat-item").clone().appendTo(".chat-box");
    var to = $("#change_lang").val();
    var elem = $(".chat-body span:last");
    if (to != "" && to != "Please Select") {
        translateChat(text, to, elem);
    }
}
function generatexml(data) {
  var __participants__=[]
  var message_xml="<messages>";  
  var dialog_id = data.dialog_id;
  let chat_list = data.chat_list;
  if(!chat_list) return "<threads></threads>";
  for (var i = 0; i< chat_list.length; i ++) {
    var msg = chat_list[i];
    var xml="<message>";
    var dateStr = moment.unix(msg.date_sent).toDate().toString();
    xml=xml+ `<timestamp> ${msg.date_sent} </timestamp> <from> ${msg.sender}</from><to>__participants__</to> <date> ${dateStr}</date> <message_id> ${msg._id} </message_id> <text> ${msg.message} </text> </message>`;
    message_xml += xml;
    dialog_id = msg.chat_dialog_id;
    if(!__participants__.includes(msg.sender))__participants__.push(msg.sender);
  }
  message_xml +="</messages>";
  var particiaptnsStr = __participants__.join(',');
  message_xml.replaceAll("__participants__", particiaptnsStr);
  var result="<threads>";
  result += "<thread> <copy_license_text>Input XML License</copy_license_text>";
  result += `<thread_id> ${dialog_id} </thread_id>`;
  result += `<meeting_id>${dialog_id}</meeting_id>`;
  result += `<user_email>${loginID}</user_email>`;
  result += `<participant_emails>${particiaptnsStr}</participant_emails>`;
  result += message_xml;
  result += "</thread>";
  result += "</threads>";
  return result;
}