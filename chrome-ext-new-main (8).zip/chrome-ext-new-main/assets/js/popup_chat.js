chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
	if(message.command == "onMessageReceived"){
		let new_message = message.data.new_message
		let dateText = moment.unix(Number(new_message.date_sent)).format("LT") +" " + getAbbrTimezone();
		let sender = new_message.sender;
		let headerText = sender + " <span class='datespan'>" + dateText + "</span>";
		ChatList.push(new_message)
		AddChatElement(headerText, new_message.message);	
		// scroll to bottom;
		$(".chat-box").animate({scrollTop:$('.chat-box')[0].scrollHeight},'slow');		
	}
})