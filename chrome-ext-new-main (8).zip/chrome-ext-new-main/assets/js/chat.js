//const hostUrl="http://192.168.108.23:8000";
const hostUrl="https://spokeperson.co";
const APPLICATION_ID = 90013;
const AUTH_KEY = "b44j9JUjzjGNeDJ";
const AUTH_SECRET = "Psz26uye59V8fOx";
const ACCOUNT_KEY = "iBnxdvT-js6Mz-1osYV_";
const CONFIG = { debug: true };
const DefaultPassword = "someSecret"
let QBCurrentUserInfo;
let QBCurrentDialogInfo;

const QBLogin = function(userRequiredParams) {
    return new Promise(function (resolve, reject) {
        QB.login(userRequiredParams, function (error, result) {
            if (error) {
                reject(error);
            } else {
                resolve(result);
            }
        });
    });
};

const QBUserCreate = function(user) {
    return new Promise(function (resolve, reject) {
        QB.users.create(user, function (error, result) {
            if (error) {
                reject(error);
            } else {
                resolve(result);
            }
        });
    });
};

const QBCreateSession = function() {
    return new Promise(function(resolve, reject) {
        QB.createSession(function(error, result) {
            if(error) {
                reject(error);
			} else {
                resolve(result);
            }
        });
    });
};

const QBConnectChat = function(userId, password=DefaultPassword){
	return new Promise(function(resolve, reject) {
        QB.chat.connect({ userId: userId, password: password }, function(error, result) {
            if(error) {
                reject(error);
			} else {
                resolve(result);
            }
        });
    });
}


const QBGetSession = function() {
    return new Promise(function(resolve, reject) {
        QB.getSession(function(error, result) {
            if(error) {
                reject(error);
            } else {
                resolve(result);
            }
        });
    });
};
function joinDialog(dialog) {
	QBCurrentDialogInfo = dialog;
	
	var dialogJid = QB.chat.helpers.getRoomJidFromDialogId(dialog._id);
	return  new Promise(function(resolve, reject) {
		try {
			  QB.chat.muc.join(dialogJid, function(error, result) {
		  	    if(error) {
	                reject(error);
					} else {
						sendJoinedInfo();
	                resolve(result);
	            }
			  });
			} catch (e) {
			  if (e.name === 'ChatNotConnectedError') {
			    // not connected to chat

			  }
			  reject(e);
			}
	});
}
function loadDialog(meeting_url){
	return new Promise(function(resolve, reject){
		var filters= {
			name:meeting_url
		}

		QB.chat.dialog.list(filters, async function (error, resp) {

			//var dialogId = resp.items[0]._id;
			//var dialogJid = QB.chat.helpers.getRoomJidFromDialogId(dialogId);

			//try {
			//	QB.chat.muc.listOnlineUsers(dialogJid, function (users) {

			//	});
			//} catch (e) {
			//	if (e.name === 'ChatNotConnectedError') {
			//		// not connected to chat
			//	}
			//}

			let total_entries = resp.total_entries;
			if (total_entries == undefined) {
				total_entries = 0;
			}
			if(total_entries >0){
				let dialogs = resp.items;
				let dialog = dialogs[0];
				joinDialog(dialog).then((resp)=>{
					resolve(dialog);
				}).catch((err)=>{resolve(undefined)});
				
			}else{
				var params = {
				  type: 1,
				  name: meeting_url,
				  data:{
				    "meeting_url":meeting_url
				  }
				};
				QB.chat.dialog.create(params, function(error, dialog) {
					fetch(`${hostUrl}/accounts/update-meeting-link/`, {
						method: "POST",
						body: JSON.stringify({ "meeting_link": meeting_url, "dialog_id": dialog._id })
					})
					.then(res => res.json())
					.then(respone => console.log(response))
					joinDialog(dialog).then((resp)=>{
						resolve(dialog);
					}).catch((err)=>{resolve(undefined)});
				});
			}				
			
		});
	})
}
function loadChatHistory(email, meeting_url, password=DefaultPassword){
	return new Promise(async function(resolve, reject) {
		if(!meeting_url) reject("meeting url is not specified");
		if(!IsQBInitialized){
			IsQBInitialized = await SetupQB(email, meeting_url, password);			
		}
		if (IsQBInitialized) {
			if (meeting_url != last_meeting_url) {
				
				let dialog = await loadDialog(meeting_url);
				if(!dialog){reject("Loading Dialog Failed");}
				SubscribeMessageEvent();
				let msgs;
				try{
					msgs = _loadChatHistoryFromDialog(QBCurrentDialogInfo).then(msgs=>{
						last_chat_list = msgs;
						last_dialog_id=QBCurrentDialogInfo._id;
						last_meeting_url = meeting_url;
						resolve({dialogID:QBCurrentDialogInfo._id, msgs:last_chat_list});						
					}).catch(err=>{
						reject(err);
					});
					


				}catch(e){
					reject(e);
				}
			}else{
				resolve({dialogID:QBCurrentDialogInfo._id, msgs:last_chat_list});
			}

			
		}
	});
}
function _loadChatHistoryFromDialog(dialog) {
	return  new Promise(function(resolve, reject) {
		var dialogId = dialog._id;
	    
		var params = {
		  chat_dialog_id: dialogId,
		  sort_desc: 'date_sent',
		  limit: 100,
		  skip: 0
		};

		QB.chat.message.list(params, function(error, resp) {
		    if(error) reject(error);
		    else resolve(resp.items);		    
		});
	});	
}
function SetupQB(email, meeting_url, password=DefaultPassword){
	return new Promise(async function(resolve, reject) {		

		const userRequiredParams={
			login:email,
			password:password,
			full_name:email
		}
		QB.init(APPLICATION_ID, AUTH_KEY, AUTH_SECRET, ACCOUNT_KEY, CONFIG);
		let session;
		try{
			session= await QBGetSession();
		}catch(e){
			session = await QBCreateSession();
		}
	    try {
	        QBCurrentUserInfo = await QBLogin(userRequiredParams);
	    }catch (e) {
	        var data = await QBUserCreate(userRequiredParams);
	        QBCurrentUserInfo = await QBLogin(userRequiredParams);
	    }
    
    	try{
    		await QBConnectChat(QBCurrentUserInfo.id, password);			
    	}catch(e){
    		reject(false);
		}
		var filters = {
			name: meeting_url
		}
		//QB.chat.dialog.list(filters, async function (error, resp) {

		//	var dialogId = resp.items[0]._id;
		//	var dialogJid = QB.chat.helpers.getRoomJidFromDialogId(dialogId);

		//	try {
		//		QB.chat.muc.listOnlineUsers(dialogJid, function (users) {
		//			console.log(users);
		//		});
		//	} catch (e) {
		//		if (e.name === 'ChatNotConnectedError') {
		//			// not connected to chat
		//		}
		//	}
		//});

    	resolve(true);
	});	
}

var synth = window.speechSynthesis;

var voices = [];

function populateVoiceList() {
	voices = synth.getVoices().sort(function (a, b) {
		const aname = a.name.toUpperCase(), bname = b.name.toUpperCase();
		if (aname < bname) return -1;
		else if (aname == bname) return 0;
		else return +1;
	});
}

if (speechSynthesis.onvoiceschanged !== undefined) {
	speechSynthesis.onvoiceschanged = populateVoiceList;
}

function speak(name) {
	synth = window.speechSynthesis;
	populateVoiceList();
	//if (synth.speaking) {
	//	console.error('speechSynthesis.speaking');
	//	return;
	//}

	if (name.indexOf("guest") > -1) {
		name = "Guest";
	}

	var utterThis = new SpeechSynthesisUtterance(name + " has joined dialoggBox.");
	utterThis.onend = function (event) {
		console.log('SpeechSynthesisUtterance.onend');
	}
	utterThis.onerror = function (event) {
		console.error('SpeechSynthesisUtterance.onerror');
	}
	console.log(voices);
	utterThis.voice = voices[11];
	utterThis.pitch = 1;
	utterThis.rate = 1;
	synth.speak(utterThis);

}



function onMessage(userId, message) {
	console.log("On Message");
	if (message.extension.save_to_history == 0) { 
		speak(message.extension.sender);
		return;
	}
	var body = message.body;
	if (message.extension.isPrivate == 1) {
		if (LoginData.login_id != message.extension.sender) {
			body = "Private Message";
		}
		else {
			body = `<i class="fa-lock fa" style="
    margin-right: 10px;
"></i>` + body
		}
	}

	let new_message = {
		_id:message.extension.message_id, 
		chat_dialog_id:message.dialog_id,
		sender:message.extension.sender,
		message: body,
		date_sent:message.extension.date_sent
	}

	//update Chat list
	last_chat_list.unshift(new_message);
	//updateData(new_message);
	chrome.runtime.sendMessage({command:"onMessageReceived",data:{
			new_message:new_message
		}
	});
};



function SubscribeMessageEvent() {
	QB.chat.onMessageListener = onMessage;
}
function sendTextMessage(text) {
	var msg = text.split('_')[0];
	var IsPrivate = text.split('_')[1];
	if(!QBCurrentDialogInfo) return;
	let dialog = QBCurrentDialogInfo;
	var message = {
		type: "groupchat",
		body: msg,
		extension: {
			save_to_history: 1,
			isPrivate: IsPrivate,
			dialog_id: dialog._id,
			sender: LoginData.login_id
		},
		markable: 1
	};
	var dialogJid = QB.chat.helpers.getRoomJidFromDialogId(dialog._id);
	try {
	  message.id = QB.chat.send(dialogJid, message);
	} catch (e) {
	  if (e.name === 'ChatNotConnectedError') {
	    // not connected to chat
	  }
	}
}

function sendCCMessage(text) {
	var msg = text.split('_')[0];
	var SenderId = text.split('_')[1];
	if (SenderId == "You") {
		SenderId = LoginData.login_id;
	}
	if (!QBCurrentDialogInfo) return;
	let dialog = QBCurrentDialogInfo;
	var message = {
		type: "groupchat",
		body: msg,
		extension: {
			save_to_history: 1,
			isPrivate: 0,
			isCC: 1,
			dialog_id: dialog._id,
			sender: SenderId //LoginData.login_id
		},
		markable: 1
	};
	var dialogJid = QB.chat.helpers.getRoomJidFromDialogId(dialog._id);
	try {
		message.id = QB.chat.send(dialogJid, message);
	} catch (e) {
		if (e.name === 'ChatNotConnectedError') {
			// not connected to chat
		}
	}
}


function sendJoinedInfo(text = "hello") {
	if (!QBCurrentDialogInfo) return;
	let dialog = QBCurrentDialogInfo;
	var message = {
		type: "groupchat",
		body: text,
		extension: {
			save_to_history: 0,
			dialog_id: dialog._id,
			sender: LoginData.login_id
		},
		markable: 0
	};
	//speak(LoginData.login_id);
	var dialogJid = QB.chat.helpers.getRoomJidFromDialogId(dialog._id);
	try {
		message.id = QB.chat.send(dialogJid, message);
		
	} catch (e) {
		if (e.name === 'ChatNotConnectedError') {
			// not connected to chat
		}
	}
}

var loginID;
var meetingURL;
var dialogID;
let loadingDialog = false;
let ChatList = [];
let globalCred;


function InitChatBox(msgs) {
	console.log(msgs);
	ChatList = [];
	for (var i = msgs.length - 1; i >= 0; i--) {
		let msg = msgs[i];
		ChatList.push(msg);
		let dateText = moment.unix(Number(msg.date_sent)).format("LT") + " " + getAbbrTimezone();
		let sender = msg.sender;
		let headerText = sender + " <span class='datespan'>" + dateText + "</span>";
		let bodyText = msg.message;
		AddChatElement(headerText, bodyText);
	}
}
function LoadingFinished(success) {
	loadingDialog = false;
	//$("#loading").addClass("display-none");
	if (success) {
		$(".main-content").removeClass("display-none");
	}
}

function SaveDialogXML(data) {
	return new Promise(function (resolve, reject) {
		let xmlStr = generatexml(data);
		const formData = new FormData();
		formData.append('xmlData', xmlStr);
		formData.append('login_id', loginID);
		formData.append('dialog_id', data.dialog_id);
		$.post({
			url: `${hostUrl}/save-input-xml-chrome/?cred=` + globalCred,
			data: formData,
			processData: false,
			contentType: false,
			cache: false,
			success: function (data) {
				resolve(data);
			}

		})
	});
}
function SaveXmlClick() {
	if (loadingDialog) return;
	window.open(hostUrl + "/loading_review_crome/", "_blank");
	// SaveDialogXML({
	//   meeting_url:meetingURL,
	//   dialog_id:dialogID,
	//   chat_list:ChatList
	// }).then((data)=>{
	//   if(data.status=="ok")
	//       {        
	//         window.open(hostUrl + "/review_all/?link_id="+data.xmlfileidname +"&isuploaded=true" + "&user_email="+loginID+"&cred="+globalCred,"_blank")

	//       }                         
	// });
}
async function showLoggedInContent() {
	$("#login-content").addClass("display-none");
	$("#loggedin-content").removeClass("display-none");
	$("#login-id").text(loginID);
	if (!meetingURL) {
		var tab = await getActiveTabInfo();
		console.log("Active Tab", tab);
		if (tab) meetingURL = tab.url
	}
	if (meetingURL) {
		chrome.runtime.sendMessage({ command: "Get Last Dialog Data" }, function (lastData) {
			if (meetingURL) {
				if (lastData.meeting_url != meetingURL) {
					if (lastData.meeting_url) SaveDialogXML(lastData);
				}
			}

			loadingDialog = true;
			$("#meeting-link").text(meetingURL);
			chrome.runtime.sendMessage({ command: "LoadChatHistory", data: { email: loginID, meeting_url: meetingURL } }, function (data) {
				if (data) {
					dialogID = data.dialogID;
					InitChatBox(data.msgs);
					LoadingFinished(true);
				} else {
					LoadingFinished(false);
				}
			})

			// SetupQB(loginID, meetingURL, dialogID).then((dialog)=>{
			//   $("#dialog-id").text(QBCurrentDialogInfo._id);
			//   dialogID = QBCurrentDialogInfo._id;
			//   QuickbloxConnected = true;
			//   SubscribeMessageEvent();
			//   loadChathistory(QBCurrentDialogInfo).then((msgs)=>{
			//     InitChatBox(msgs);
			//     LoadingFinished(true);
			//   }).catch(err=>{
			//     console.log(err);
			//     LoadingFinished(false);
			//   })
			// }).catch(e=>{
			//   alert("Setup Quick Blox failed")
			//   LoadingFinished(false);
			// });  
		});

	} else {
		LoadingFinished(false);
	}


}
function showLoginContent() {
	$("#login-content").removeClass("display-none");
	$("#loggedin-content").addClass("display-none");

}
function isLoggedIn(loginStatus) {
	loginID = loginStatus.login_id;
	dialogID = loginStatus.dialog_id;
	meetingURL = loginStatus.meeting_url;
	globalCred = loginStatus.cred;
	return loginID;
}


function routing(loginStatus) {
	//if (isLoggedIn(loginStatus)) showLoggedInContent();
	//else
		showLoginContent();
}

function sendText() {
	let text = $('#input-text').val();
	if (text) {
		chrome.runtime.sendMessage({ command: "sendText", data: text });
	}
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
	if (message.command == "onMessageReceived") {
		let new_message = message.data.new_message
		let dateText = moment.unix(Number(new_message.date_sent)).format("LT") + " " + getAbbrTimezone();
		let sender = new_message.sender;
		let headerText = sender + " <span class='datespan'>" + dateText + "</span>";
		ChatList.push(new_message)
		AddChatElement(headerText, new_message.message);
		// scroll to bottom;
		$(".chat-box").animate({ scrollTop: $('.chat-box')[0].scrollHeight }, 'slow');
	}
});

$(document).ready(function () {
	chrome.runtime.sendMessage({ command: "loginstatus" }, routing);
	 
	$("#send-text-btn").on("click", sendText);
	$('#save_xml').on("click", SaveXmlClick);
});