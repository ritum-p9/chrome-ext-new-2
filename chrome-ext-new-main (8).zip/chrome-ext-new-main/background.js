
const SIGN_IN_URL = "http://spokeperson.co/accounts/login_extension/?next_url=/?";

//const SIGN_IN_URL = "https://dialoggbox.tk/accounts/login_extension/?next_url=/?";

//chrome.tabs.create({ url: "popup_redesigned.html" }); 
var mUrl = "";
var mEmail = "";
//chrome.windows.getCurrent(function (w) {
//    chrome.tabs.getSelected(w.id,
//        function (response) {
//            mUrl = response.url;
//        });
//});

var LoginData = {
    login_id: undefined,//undefined,
    login_password: undefined,//undefined,
    login_method: 'gmail',
    cred: undefined,
    meeting_url: mUrl,
    dialog_id: undefined
}


//chrome.identity.getProfileUserInfo(function (userInfo) {
//    /* Use userInfo.email, or better (for privacy) userInfo.id
//       They will be empty if user is not signed in in Chrome */
//    mEmail = userInfo.email;

//});
    var gEmail = localStorage.getItem("gEmail");
    if (gEmail != undefined && gEmail != "" && gEmail != null) {
        mEmail = gEmail;
        
    } else {
        mEmail = "guest_" + chrome.runtime.id + "@dialoggbox.com";
    }

var last_meeting_url;
var last_dialog_id;
var last_chat_list;
var IsQBInitialized=false;
let ppp = 0;
function storeLoginDataOnLocalStorage() {
  localStorage.setItem("logindata", JSON.stringify(LoginData));
}

function loadLoginDataOnLocalStorage() {
  data = localStorage.getItem("logindata")
  if(data){
    LoginData = JSON.parse(data);
  }
}

chrome.windows.getCurrent(function (w) {
    chrome.tabs.getSelected(w.id,
        function (response) {
            mUrl = response.url;
        });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if(message.command == "loginstatus"){
    ppp++;
    //if(!LoginData.login_id) {
    //  chrome.tabs.create({
    //    url:SIGN_IN_URL,
    //    active:true
    //  }, function(tab) {        
    //    // chrome.tabs.executeScript(tab.id, {file:'content_login.js', runAt:"document_start"}, (data)=>{
    //    //   console.log(data);
    //    // })
    //  })
    //}
     
      gEmail = localStorage.getItem("gEmail");


      if (gEmail != undefined && gEmail != "" && gEmail != null) {
          mEmail = gEmail;
          
      } else {
          mEmail = "guest_" + chrome.runtime.id + "@dialoggbox.com";
          
      }

      var Gmail = "";
      chrome.storage.local.get(["Gmail"], function (items) {
          //  items = [ { "phasersTo": "awesome" } ]
          mEmail = items.Gmail;
          Gmail = items.Gmail;
      });

      var checkGmail = setInterval(function () {
          if (Gmail!= "") {
              clearInterval(checkGmail);
          }
      }, 100);

      

      //chrome.tabs.query({ active: true, lastFocusedWindow: true }, tabs => {
      //    LoginData.meeting_url = tabs[0].url;
      //    // use `url` here inside the callback because it's asynchronous!
      //});

      chrome.tabs.onUpdated.addListener(function (tabID, info, tab) {
          localStorage.setItem("cUrl", tab.url);
      });

    chrome.windows.getCurrent(function (w) {
          chrome.tabs.getSelected(w.id,
              function (response) {
                  mUrl = response.url;
                  LoginData = {
                      login_id: mEmail,//undefined,
                      login_password: undefined,//undefined,
                      login_method: 'gmail',
                      cred: undefined,
                      meeting_url: mUrl,
                      dialog_id: undefined
                  }
                 
                  //speak(mEmail);
                  sendResponse(LoginData);
              });
    });
      
  }
  if(message.command == "LoadChatHistory"){
      loadChatHistory(message.data.email, message.data.meeting_url).then(data => {
         // alert(message.data.email + " has joined");
      sendResponse(data);
    }).catch(err=>{
      sendResponse(undefined);      
    });    
  }
  if(message.command == "sendText"){
    sendTextMessage(message.data)
    return false;
    }
    if (message.command == "sendCC") {
        sendCCMessage(message.data)
        return false;
    }
    if (message.command == "joined") {
        sendJoinedInfo();
        return false;
    }
  if(message.command == "Set Guest Login Data"){
    LoginData = message.data;
    storeLoginDataOnLocalStorage()
    return false;
    }
    if (message.command == "writeCaption") {
        alert("done");
        return false;
    }
  if(message.command == "Set Login Data"){
    LoginData = message.data;
    storeLoginDataOnLocalStorage()
    return false;
  }
  if(message.command == "Set Credential"){
    LoginData.cred = message.data;
    storeLoginDataOnLocalStorage()
    return false;
  }
  if(message.command == "Set Last Dialog Data"){
    let data = message.data;    
    last_meeting_url = data.meeting_url;
    last_dialog_id = data.dialog_id;
    last_chat_list = data.chat_list;    
    localStorage.setItem("last_meeting_url", last_meeting_url)
    localStorage.setItem("last_dialog_id", last_dialog_id)
    localStorage.setItem("last_chat_list", JSON.stringify(last_chat_list));

    return false;
  }
  if(message.command == "Get Last Dialog Data"){
    sendResponse({
      meeting_url:last_meeting_url,
      dialog_id:last_dialog_id,
      chat_list:last_chat_list
    })
    return true;
  }
  if(message.command == "Load Transcript"){
    data={
      meeting_url:last_meeting_url,
      dialog_id:last_dialog_id,
      chat_list:last_chat_list
    }

    let xmlStr = generatexml(data)
    let ret_data ={
      xmlData:xmlStr,
      dialog_id:data.dialog_id
    }
    
    sendResponse(ret_data);
    return true;
  }
  if(message.command =="logout"){
    LoginData = {
      login_id:undefined,
      login_password:undefined,
      login_method:undefined,
      cred:undefined,
      meeting_url:undefined,
      dialog_id:undefined
    } 
    storeLoginDataOnLocalStorage();
    return false;
  }
  return true;
});
loadLoginDataOnLocalStorage();


