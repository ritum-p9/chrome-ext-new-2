$(document).ready (jQueryMain);

function jQueryMain () {
    alert("helo");
    $("body").append ('<p>Added by jQuery</p>');
}