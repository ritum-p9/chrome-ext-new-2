﻿$(document).ready(function () {
    $("#btn").click(function () {
        localStorage.setItem("gEmail", $("#emailId").val());
        var gEmail = localStorage.getItem("gEmail");
        if (gEmail != undefined && gEmail != "" && gEmail != null) {
            $("#login-id").text("Logged In as: " + gEmail);
           // $(".login").hide();
        }
    });

    var gEmail = localStorage.getItem("gEmail");
    if (gEmail != undefined && gEmail != "" && gEmail != null) {
        $("#login-id").text("Logged In as: " + gEmail);
        //$(".login").hide();
    }



    var Gmail = "";
    chrome.storage.local.get(["Gmail"], function (items) {
        //  items = [ { "phasersTo": "awesome" } ]
        $("#login-id").text("Logged In as: " + items.Gmail);
        Gmail = items.Gmail;
    });

    var checkGmail = setInterval(function () {
        if (Gmail != "") {
            clearInterval(checkGmail);
        }
    }, 100);




});