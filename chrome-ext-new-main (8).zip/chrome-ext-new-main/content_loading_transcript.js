document.addEventListener('DOMContentLoaded', function() {
    // this code will run when the DOM is ready
    window.postMessage({ foo: 'bar', text: "Hello from content script!" }, "*");
});

chrome.runtime.sendMessage({command: "Load Transcript"}, function(loadedScriptFormData){
	console.log("inject loading transcript");
	window.postMessage(loadedScriptFormData, "*");
});

console.log("inject loading transcript");