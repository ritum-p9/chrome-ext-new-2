// (function(){
//         $.get(chrome.runtime.getURL('/template.html'), function(data) {
//             wait(3000);
//             $(data).appendTo('.jmSZUc:last');
            
//             //document.querySelector("body").append(data);
//             // Or if you're using jQuery 1.8+:
//             // $($.parseHTML(data)).appendTo('body');
//         });

// })();

var html =`<div class="icon_label">
<img src="https://uploads-ssl.webflow.com/5fea9b051844a69dc7585d22/606ef418c2403d88b5888c9b_6057e2805e94b108cf734f2b_logo_new_outline_sq_sm.png">
</div>`;


$(function()
{

$(window).bind('load', function()
{
    $.get(chrome.runtime.getURL('/template.html'), function (data) {
        
        //wait(3000);
        var checkExist = setInterval(function() {
            if ($('.SGP0hd.kunNie').length) {
                //$(".VfPpkd-Bz112c-LgbsSe.yHy1rc.eT1oJ.JsuyRc.boDUxc").eq(1).click();

                
                var checkNameExist = setInterval(function() {
                    if ($('.ZjFb7c').text() != "") {
                         var name = $(".ZjFb7c").html();
                        //$(".VUk8eb").click();
                        
                //$("#username").html(name);
                       clearInterval(checkNameExist);
                    }
                 }, 100);



                $(html).appendTo('.SGP0hd.kunNie');
                $(data).appendTo('body');
                //$("#date").html(new Date());
                //$("#meetlink").html(window.location.href);

                    //chrome.runtime.sendMessage({ command: "loginstatus" }, routing);
                    //$("#send-text-btn").on("click", sendText);
                    //$('#save_xml').on("click", SaveXmlClick);

                


                $(".icon_label").click(function () {
                    if($("#call-us-cta").hasClass("hidden")){
                        $("#call-us-cta").removeClass("hidden");
                    }else{
                        $("#call-us-cta").addClass("hidden");
                    }
                });

               clearInterval(checkExist);
            }
         }, 100); // check every 100ms

        //$(data).appendTo('body');
        
        //document.querySelector("body").append(data);
        // Or if you're using jQuery 1.8+:
        // $($.parseHTML(data)).appendTo('body');
    });
});
});


function wait(ms){
    var start = new Date().getTime();
    var end = start;
    while(end < start + ms) {
      end = new Date().getTime();
   }
 }